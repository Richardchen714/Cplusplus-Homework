//Square.h
#ifndef SQUARE_H
#define SQUARE_H
#include<stdexcept>
#include"Rectangle.h"
#include"Circle.h"
using std::invalid_argument;
class Square :Rectangle {
public:
	Square(const Point A_ = (0, 0), const Point B_ = (0, 0), const Point C_ = (0, 0), const Point D_ = (0, 0), string Id = "")
	{
		A = A_;
		B = B_;
		C = C_;
		D = D_;
		a = A.distance(B);
		b = B.distance(C);
		id = Id;
		if (a != b) throw invalid_argument("a must equal to b.");
		incircle = Circle(Point((A.getX() + C.getX()) / 2.0, (A.getY() + C.getY()) / 2.0), A.distance(C) / 2.0);
	}
	void print()const
	{
		cout << "The square's name is :" << Shape::id<<endl;
		cout << "The four points of the square are: "<<endl;
		A.print();
		cout << ",";
		B.print();
		cout << ",";
		C.print();
		cout << ",";
		D.print();
		cout << endl;
		cout << "The square of the rectangle is: " << area()<<endl;
		cout << "The incircle: "<<endl;
		incircle.print();
	}
private:
	Circle incircle;
};
#endif