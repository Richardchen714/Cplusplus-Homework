//Rectangle.h
#ifndef RECTANGLE_H
#define RECTANGLE_H
#include"shape.h"
class Rectangle :public Shape{
public:
	Rectangle(const Point A_=(0,0),const Point B_=(0,0),const Point C_=(0,0), const Point D_=(0,0),string Id="")
	{
		A = A_;
		B = B_;
		C = C_;
		D = D_;
		a = A.distance(B);
		b = B.distance(C);
		id = Id;
	}
	~Rectangle(){}
	double area()const
	{
		return a * b;
	}
	void print()const
	{
		cout << "The rectangle's name is :" << id<<endl;
		cout << "The four points of the rectangle are: ";
		A.print();
		cout << ",";
		B.print();
		cout << ",";
		C.print();
		cout << ",";
		D.print();
		cout << endl;
		cout << "The square of the rectangle is: " << area()<<endl<<endl;
	}
protected:
	Point A, B, C, D;
	double a, b;
};
#endif