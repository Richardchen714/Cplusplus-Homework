//Triangle.h
#ifndef TRIANGLE_H
#define TRIANGLE_H
#include"shape.h"
class Triangle :public Shape{
public:
	Triangle(const Point A_=(0,0),const Point B_=(0,0),const Point C_=(0,0),const string Id="")
	{
		A = A_;
		B = B_;
		C = C_;
		a = B_.distance(C_);
		b = C_.distance(A_);
		c = A_.distance(B_);
		id = Id;
	}
	~Triangle(){}
	double area()const
	{
		double p = (a + b + c) / 2.0;
		return sqrt(p*(p-a)*(p-b)*(p-c));
	}
	void print()const
	{
		cout << "The triangle's name is :" << id<<endl;
		cout << "The three points of the triangle are: ";
		A.print();
		cout << ",";
		B.print();
		cout << ",";
		C.print();
		cout << endl;
		cout << "The square of the triangle is: " << area()<<endl<<endl;
	}
private:
	Point A, B, C;
	double a, b, c;
};
#endif