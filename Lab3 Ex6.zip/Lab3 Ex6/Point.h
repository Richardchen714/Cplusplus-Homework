//Point.h
#ifndef POINT_H
#define POINT_H
#include<iostream>
#include<cmath>
using std::cout;
class Point {
public:
	Point(const double X = 0, const double Y = 0)
	{
		x = X; y = Y;
	}
	~Point(){}
	void print()const
	{
		cout << "(" << x << "," << y << ")";
	}
	double distance(const Point a)const
	{
		return sqrt((x - a.x) * (x - a.x) + (y - a.y) * (y - a.y));
	}
	double getX()const { return x; }
	double getY()const { return y; }
private:
	double x, y;
};
#endif