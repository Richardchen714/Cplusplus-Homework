//Shape.h
#ifndef SHAPE_H
#define SHAPE_H
#include<iostream>
#include<string>
#include"Point.h"
using std::cout;
using std::endl;
using std::string;
class Shape {
public:
	Shape(const string ID="")
	{
		id = ID;
	}
	~Shape(){}
protected:
	string id;
};
#endif