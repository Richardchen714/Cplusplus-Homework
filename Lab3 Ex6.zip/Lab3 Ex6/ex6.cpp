//Ex6.h
#include<iostream>
#include"Point.h"
#include"shape.h"
#include"Circle.h"
#include"Triangle.h"
#include"Rectangle.h"
#include"Square.h"
using namespace std;
int main()
{
	Circle A(Point(0, 0), 1.0,"A");
	Triangle B(Point(0, 0), Point(1, 1), Point(0, 1), "B");
	Rectangle C(Point(0, 0), Point(2, 0), Point(2, 1), Point(0, 1), "C");
	Square D(Point(0, 0), Point(0, 1), Point(1, 1), Point(1, 0), "D");
	A.print();
	B.print();
	C.print();
	D.print();
	return 0;
}