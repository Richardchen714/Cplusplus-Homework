//Circle.h
#ifndef CIRCLE_H
#define CIRCLE_H
#include"shape.h"
class Circle :public Shape{
public:
	Circle(const Point O=(0,0), const double r=0.0,const string Id="")
	{
		CenterOfCircle = O;
		radius = r;
		id = Id;
	}
	~Circle(){}
	double area()const
	{
		return 3.14 * radius * radius;
	}
	void print()const
	{
		cout << "The name of the circle is: " << id<<endl;
		cout << "The radius is " << radius<<endl;
		cout << "The center of circle is: ";
		CenterOfCircle.print();
		cout << endl;
		cout << "The square is: " << area()<<endl<<endl;
	}
private:
	Point CenterOfCircle;
	double radius;
};
#endif