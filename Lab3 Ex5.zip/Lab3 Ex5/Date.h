//Date.h
#ifndef DATE_H
#define DATE_H
class Date{
public:
	Date(int y=0,int m=0,int d=0)
	{
		year=y;
		month=m;
		day=d;
	}
	int getY()
	{
		return year;
	}
	int getM()
	{
		return month;
	}
	int getD()
	{
		return day;
	}
	void setY(int y)
	{
		year=y;
	}
	void setM(int y)
	{
		month=y;
	}
	void setD(int y)
	{
		day=y;
	}
private:
	int year,month,day;
};
#endif