//FinalTest.h
#ifndef FINALTEST_H
#define FINALTEST_H
#include<iostream>
#include<string>
#include"Date.h"
using std::string;
using std::cout;
using std::endl;
class FinalTest:public Date
{
public:
	FinalTest(string n="",Date d=Date(2014,1,1)):name(n),Date(d){}
	void print()
	{
		cout<<"Title: "<<name<<endl;
		cout<<"Date: "<<Date::getY()<<"-"<<Date::getM()<<"-"<<Date::getD()<<endl;
	}
	void setDue(Date d)
	{
		setY(d.getY());
		Date::setM(d.getM());
		Date::setD(d.getD());
	}
private:
	string name;
};
#endif