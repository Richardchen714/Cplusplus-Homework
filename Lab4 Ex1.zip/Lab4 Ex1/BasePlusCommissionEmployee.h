//BasePlusCommissionEmployee.h
#ifndef BASEPLUSCOMMISSIONEMPLOYEE_H
#define BASEPLUSCOMMISSIONEMPLOYEE_H
#include"CommissionEmployee.h"
class basePlusCommissionEmployee : public commissionEmployee {
public:
	basePlusCommissionEmployee(const string& f, const string& l, const string& ssn, const Date d = (1, 1, 1900), double sales=0.0, double rate=0.0, double salary=0.0)
		:commissionEmployee(f, l, ssn,d, sales, rate), baseSalary(salary)
	{
	}
	virtual ~basePlusCommissionEmployee() { cout << "deleting object of class BasePlusCommissionEmployee"<<endl; }
	double getBS()const { return baseSalary; }
	double getGS()const { return commissionEmployee::getGS(); }
	double getCR()const { return commissionEmployee::getCR(); }
	virtual double earnings()const override
	{
		return getBS() + getGS() * getCR() + (isBirthMonth() ? 100 : 0);
	}
	virtual void print()const override
	{
		cout << "base-salaried commission employee: ";
		Employee::print();
		cout << endl << "gross sales: " << getGS() <<";" << "commission rate: " << getCR()<<";" << "Base Salary: " << getBS() << endl;
		if (isBirthMonth()) cout << "HAPPY BIRTHDAY!"<<endl;
		cout << "earned: $" << earnings();
	}
private:
	double baseSalary;
};
#endif