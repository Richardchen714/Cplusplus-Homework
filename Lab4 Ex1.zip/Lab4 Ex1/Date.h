//Date.h
#ifndef DATE_H
#define DATE_H
#include<string>
#include<iostream>
using std::string;
using std::cout;
class Date {
public:
	Date(int m = 1, int d = 1, int y = 1900)
	{
		Month = m;
		day = d;
		year = y;
	}
	int getM()const { return Month; }
	void print()const
	{
		cout << month[Month - 1] << " " << day << ", " << year;
	}
private:
	unsigned int Month, day, year;
	const string month[12] = { "January","February","March","April","May","June","July","August","September","October","November","December" };
};
#endif