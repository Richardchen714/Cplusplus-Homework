//Employee.h
#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>
#include<string>
#include<windows.h>
#include"Date.h"
using std::string;
using std::cout;
using std::endl;
class Employee {
public:
	Employee(const string& F = "", const string& L = "", const string& ssn = "", const Date& d=(1,1,1900))
		:firstName(F), lastName(L), socialSecurityNumber(ssn), birthDate(d)
	{
	}
	virtual ~Employee(){}
	void SetFirstName(const string& f) { firstName = f; }
	string getFirstName()const { return firstName; }
	void SetLastName(const string& f) { lastName = f; }
	string getLastName()const { return lastName; }
	void SetSecurityNumber(const string& f) { socialSecurityNumber = f; }
	string getSocialSecurityNumber()const { return socialSecurityNumber; }
	Date getDate() { return birthDate; }
	bool isBirthMonth()const
	{
		SYSTEMTIME system;
		GetLocalTime(&system);
		return birthDate.getM()==system.wMonth?true:false;
	}
	virtual double earnings()const = 0;
	virtual void print()const
	{
		cout << getFirstName() << " " << getLastName() << endl;
		cout << "birthday: ";
		birthDate.print();
		cout << endl;
		cout<< "Social Security number: " << getSocialSecurityNumber();
	}
private:
	string firstName, lastName, socialSecurityNumber;
	Date birthDate;
};
#endif