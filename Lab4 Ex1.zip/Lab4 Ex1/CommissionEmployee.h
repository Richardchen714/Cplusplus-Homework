//CommissionEmployee.h
#ifndef COMMISSIONEMPLOYEE_H
#define COMMISSIONEMPLOYEE_H
#include"Employee.h"
class commissionEmployee : public Employee {
public:
	commissionEmployee(const string& f, const string& l, const string& ssn, const Date d = (1, 1, 1900), double sales=0.0, double rate=0.0)
		:Employee(f, l, ssn, d), grossSales(sales), commissionRate(rate)
	{
	}
	virtual ~commissionEmployee() { cout << "deleting object of class CommissionEmployee"<<endl; }
	double getGS()const { return grossSales; }
	double getCR()const { return commissionRate; }
	virtual double earnings()const override
	{
		return getGS() * getCR() + (isBirthMonth() ? 100 : 0);
	}
	virtual void print()const override
	{
		cout << "commission employee: ";
		Employee::print();
		cout << endl << "gross sales: " << getGS() <<";" << "commission rate: " << getCR()<<endl;
		if (isBirthMonth()) cout << "HAPPY BIRTHDAY!"<<endl;
		cout << "earned: $" << earnings();
	}
private:
	double grossSales;
	double commissionRate;
};
#endif