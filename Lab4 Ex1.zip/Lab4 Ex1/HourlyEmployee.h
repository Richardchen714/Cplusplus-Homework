//HourlyEmployee.h
#ifndef HOURLYEMPLOYEE_H
#define HOURLYEMPLOYEE_H
#include"Employee.h"
class hourlyEmployee :public Employee {
public:
	hourlyEmployee(const string& f = "", const string& l = "", const string& ssn = "", const Date d = (1, 1, 1900), double hw = 0.0, int wh = 0) :
		Employee(f, l, ssn,d), hourWage(hw), workedHour(wh)
	{
	}
	virtual ~hourlyEmployee() { cout << "deleting object of class HourlyEmployee"<<endl; }
	double getWH()const { return workedHour; }
	double getHW()const { return hourWage; }
	virtual double earnings() const override
	{
		return getWH() * getHW() + (isBirthMonth() ? 100 : 0);
	}
	virtual void print() const override
	{
		cout << "hourly Employee: ";
		Employee::print();
		cout << endl << "hourly wage: " << hourWage << "; hours worked: " << workedHour<<endl;
		if (isBirthMonth()) cout << "HAPPY BIRTHDAY!"<<endl;
		cout  << "earned: $" << earnings();
	}
private:
	double hourWage;
	int workedHour;
};//finish
#endif