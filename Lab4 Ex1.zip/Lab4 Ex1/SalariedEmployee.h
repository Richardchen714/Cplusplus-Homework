//SalariedEmployee.h
#ifndef SALARIEDEMPLOYEE_H
#define SALARIEDEMPLOYEE_H
#include"Employee.h"
class salariedEmployee :public Employee {
public:
	salariedEmployee(const string& f = "", const string& l = "", const string& ssn = "", const Date d=(1,1,1900), const double salary = 0.0)
		:Employee(f, l, ssn,d), weeklySalary(salary)
	{
	}
	virtual ~salariedEmployee() { cout << "deleting object of class SalariedEmployee"<<endl; }
	double getWS()const { return weeklySalary; }
	virtual double earnings() const override
	{
		return getWS() + (isBirthMonth() ? 100 : 0);
	}
	virtual void print() const override
	{
		cout << "salaried employee: ";
		Employee::print();
		cout <<endl<< "WeeklySalary: " << getWS();
		if (isBirthMonth()) cout <<endl<< "HAPPY BIRTHDAY!"<<endl;
		cout << endl << "earned: $" << earnings();
	}
private:
	double weeklySalary;
};
#endif
