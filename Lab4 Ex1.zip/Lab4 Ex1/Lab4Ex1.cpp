//Lab4Ex1.cpp
#include<iostream>
#include<iomanip>
#include<vector>
#include<string>
#include"Date.h"
#include"Employee.h"
#include"SalariedEmployee.h"
#include"HourlyEmployee.h"
#include"CommissionEmployee.h"
#include"BasePlusCommissionEmployee.h"
using namespace std;
void virtualViaRef(const Employee& baseRef)
{
	baseRef.print();
	cout << endl<<endl;
}
int main()
{
	cout << fixed << setprecision(2);
	cout << "Employees processed polymorphically via dynamic binding:" << endl << endl;
	salariedEmployee se("John", "Smith", "111-11-1111", Date(6, 15, 1944), 800.00);
	hourlyEmployee he("Karen", "Price", "222-22-2222", Date(5, 29, 1960), 16.75, 40);
	commissionEmployee ce("Sue", "Jones", "333-33-3333", Date(9, 8, 1954), 10000.0, 0.06);
	basePlusCommissionEmployee bpce("Bob", "Lewis", "444-44-4444", Date(3, 2, 1965), 5000.00, 0.04, 300.00);
	vector<Employee*>employees;
	employees.push_back(&se);
	employees.push_back(&he);
	employees.push_back(&ce);
	employees.push_back(&bpce);
	for (const Employee* employeePtr : employees)
		virtualViaRef(*employeePtr);
	return 0;
}