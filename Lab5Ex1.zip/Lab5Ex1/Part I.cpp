#include<iostream>
#include<fstream>
#include<iomanip>
#include<cstdlib>
#include<random>
#include<ctime>
using namespace std;
int main()
{
	ofstream outClientFile("Contents of Record.txt",ios::out);
	if(!outClientFile)
	{
		cerr<<"Files cannot be opened."<<endl;
		exit(EXIT_FAILURE);
	}
	default_random_engine engine(time(0));
	uniform_int_distribution<unsigned int>randomIP(0,255);
	uniform_int_distribution<unsigned int>randomYear(2000,2025);
	uniform_int_distribution<unsigned int>randomMonth(1,12);
	uniform_int_distribution<unsigned int>randomDay(1,31);
	uniform_int_distribution<unsigned int>randomHour(0,23);
	uniform_int_distribution<unsigned int>randomMinute(1,60);
	for(int i=0;i<100;i++)
	{
		outClientFile<<randomIP(engine)<<"."<<randomIP(engine)<<"."<<randomIP(engine)<<"."<<randomIP(engine)<<" ";
		
		int m=randomMonth(engine);
		int y=randomYear(engine);
		outClientFile<<setfill('0')<<y<<"-"<<setw(2)<<m<<"-";
		if(m==1||m==3||m==5||m==7||m==8||m==10||m==12) outClientFile<<setfill('0')<<setw(2)<<randomDay(engine);
		else if(m==4||m==6||m==9||m==11) outClientFile<<setfill('0')<<setw(2)<<randomDay(engine)%30+1;
		else if(m==2&&y%4) outClientFile<<setfill('0')<<setw(2)<<randomDay(engine)%28+1;
		else if(m==2&&y%4==0) outClientFile<<setfill('0')<<setw(2)<<randomDay(engine)%29+1;
		outClientFile<<" "<<setfill('0')<<setw(2)<<randomHour(engine)<<":"<<setw(2)<<randomMinute(engine)<<":"<<setw(2)<<randomMinute(engine)<<endl;
	}
	system("pause");
	return 0;
}